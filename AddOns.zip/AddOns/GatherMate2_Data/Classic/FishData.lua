GatherMateData2FishDB = {
}
