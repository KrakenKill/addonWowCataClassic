# Immersion

## [1.4.42](https://github.com/seblindfors/Immersion/tree/1.4.42) (2024-12-10)
[Full Changelog](https://github.com/seblindfors/Immersion/compare/1.4.41...1.4.42) [Previous Releases](https://github.com/seblindfors/Immersion/releases)

- Update Immersion.toc  
- Merge pull request #46 from Witnesscm/master  
    Fix nil error on Classic  
- Fix nil error on Classic  
- Merge pull request #43 from Witnesscm/master  
    Fix skill point rewards  
- Fix nil error on Classic  
- Fix daily quest icon  
- Fix greeting quest icon and cleanup old APIs  
- Fix skill point rewards  
