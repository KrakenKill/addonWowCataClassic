# Bartender4

## [4.15.2](https://github.com/Nevcairiel/Bartender4/tree/4.15.2) (2025-01-10)
[Full Changelog](https://github.com/Nevcairiel/Bartender4/compare/4.15.1...4.15.2) [Previous Releases](https://github.com/Nevcairiel/Bartender4/releases)

- Replace OptionsButtonTemplate on all flavors  
- Update TOC for various patch updates  
- Update Micro Menu vehicle re-anchoring for Cata Classic  
- Remove WoW 10.x micro menu data  
