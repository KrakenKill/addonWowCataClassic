# GatherMate2

## [1.47.7-classic](https://github.com/Nevcairiel/GatherMate2/tree/1.47.7-classic) (2024-11-28)
[Full Changelog](https://github.com/Nevcairiel/GatherMate2/compare/1.47.6-classic...1.47.7-classic) [Previous Releases](https://github.com/Nevcairiel/GatherMate2/releases)

- Update deprecated API call  
- Remove old options panel trickery  
- Update Tracking API for Firelands update  
